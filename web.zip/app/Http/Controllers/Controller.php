<?php

namespace App\Http\Controllers;

use Google\Service\CloudSearch\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema as FacadesSchema;

abstract class Controller
{
    //


}
